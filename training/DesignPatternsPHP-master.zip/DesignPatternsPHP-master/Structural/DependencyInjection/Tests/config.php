<?php

return array('host' => 'github.com');
