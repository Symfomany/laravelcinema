<?php

namespace DesignPatterns\Structural\Bridge;

/**
 * Implementer.
 */
interface Workshop
{
    public function work();
}
