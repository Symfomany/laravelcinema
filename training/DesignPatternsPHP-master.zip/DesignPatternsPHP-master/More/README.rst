More
====

.. toctree::
   :titlesonly:

   Delegation/README
   ServiceLocator/README
   Repository/README
