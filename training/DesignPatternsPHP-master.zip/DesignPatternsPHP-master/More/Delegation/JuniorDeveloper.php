<?php

namespace DesignPatterns\More\Delegation;

/**
 * Class JuniorDeveloper.
 */
class JuniorDeveloper
{
    public function writeBadCode()
    {
        return 'Some junior developer generated code...';
    }
}
