<?php

namespace DesignPatterns\More\ServiceLocator;

class LogService implements LogServiceInterface
{
}
