<?php

namespace DesignPatterns\Creational\Singleton;

class SingletonPatternViolationException extends \Exception
{
}
