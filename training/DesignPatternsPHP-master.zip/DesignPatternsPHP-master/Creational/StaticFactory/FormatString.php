<?php

namespace DesignPatterns\Creational\StaticFactory;

/**
 * Class FormatString.
 */
class FormatString implements FormatterInterface
{
}
