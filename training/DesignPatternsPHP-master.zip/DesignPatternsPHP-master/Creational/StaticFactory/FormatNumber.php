<?php

namespace DesignPatterns\Creational\StaticFactory;

/**
 * Class FormatNumber.
 */
class FormatNumber implements FormatterInterface
{
}
