<?php

namespace DesignPatterns\Creational\StaticFactory;

/**
 * Class FormatterInterface.
 */
interface FormatterInterface
{
}
