<?php

namespace DesignPatterns\Creational\Builder\Parts;

/**
 * Class Wheel.
 */
class Wheel
{
}
