<?php

namespace DesignPatterns\Creational\Builder\Parts;

/**
 * Class Engine.
 */
class Engine
{
}
