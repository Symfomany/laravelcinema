<?php

namespace DesignPatterns\Creational\Builder\Parts;

/**
 * Car is a car.
 */
class Car extends Vehicle
{
}
