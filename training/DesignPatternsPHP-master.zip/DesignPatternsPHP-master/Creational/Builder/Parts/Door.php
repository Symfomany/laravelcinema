<?php

namespace DesignPatterns\Creational\Builder\Parts;

/**
 * Class Door.
 */
class Door
{
}
