<?php

namespace DesignPatterns\Creational\Builder\Parts;

/**
 * Bike is a bike.
 */
class Bike extends Vehicle
{
}
